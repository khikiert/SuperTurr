/* 

TestRotozoom.c: test program for rotozoom routines

(C) A. Schiffler, 2001-2011, zlib License

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "TestRotozoomSTurri.h"

#include "SDL.h"
#include "SDL_image.h"

#ifdef WIN32
#include <windows.h>
#include "SDL_gfxPrimitives.h"
#include "SDL_rotozoom.h"
#else
#include "SDL/SDL_gfxPrimitives.h"
#include "SDL/SDL_rotozoom.h"
#endif

/* Pause flag */
int pause = 0;

/* Custom rotation setup */
double custom_angle=0.0;
double custom_fx=1.0;
double custom_fy=1.0;
int custom_smooth=0;

/* Delay between frames */
int delay;

/* Curren message */
char *messageText;

void TestRotozoomSTurri::HandleEvent()
{
	SDL_Event event; 

	/* Check for events */
	while ( SDL_PollEvent(&event) || pause ) {
		switch (event.type) {
			 case SDL_KEYDOWN:
			        /* Space pauses/unpauses */
			 	if ((event.key.state==SDL_PRESSED) && 
			 	    (event.key.keysym.sym==SDLK_SPACE)) {
			 		pause = !pause;
			 		if (pause) {
			 			printf ("Paused ...\n");
			 		}
			 	}
			 	else {
			 		exit(0);
			 	}			 	
			 	break;
			 case SDL_QUIT:
				 exit(0);
				 break;
		}
		
		if (pause) {
			SDL_Delay(100);
		}
	}
}

void TestRotozoomSTurri::ClearScreen(SDL_Surface *screen)
{
	int i;
	/* Set the screen to black */
	if ( SDL_LockSurface(screen) == 0 ) {
		Uint8 *pixels;
		pixels = (Uint8 *)screen->pixels;
		for ( i=0; i<screen->h; ++i ) {
			memset(pixels, 0,
				screen->w*screen->format->BytesPerPixel);
			pixels += screen->pitch;
		}
		SDL_UnlockSurface(screen);
	}
}

#define POSITION_CENTER		1
#define POSITION_BOTTOMRIGHT	2

void TestRotozoomSTurri::RotatePicture(SDL_Surface *screen, SDL_Surface *picture, int rotate, int flip, int smooth, int position) 
{
	SDL_Surface *rotozoom_picture;
	SDL_Rect dest;
	int framecount, framemax, frameinc;
	double angle, zoomf, zoomfx, zoomfy;

	printf("%s\n", messageText);

	/* Rotate and display the picture */
	framemax=4*360; 
	frameinc=1;
	for (framecount=90; framecount<framemax; framecount += frameinc) {
		if ((framecount % 360)==0) frameinc++;
		HandleEvent();
		ClearScreen(screen);
		zoomf=(float)(framecount+2*360)/(float)framemax;
		zoomf=0.4*zoomf*zoomf;
		/* Are we in flipping mode? */
		if (flip) {
			/* Flip X factor */
			if (flip & 1) zoomfx=-zoomf;
			else zoomfx=zoomf;

			/* Flip Y factor */
			if (flip & 2) zoomfy=-zoomf;
			else zoomfy=zoomf;

			angle=framecount*rotate;
			if (((framecount % 120)==0) || (delay>0)) printf ("  Frame: %i   Rotate: angle=%.2f  Zoom: x=%.2f y=%.2f\n",framecount,angle,zoomfx,zoomfy);
			if ((rotozoom_picture=rotozoomSurfaceXY (picture, angle, zoomfx, zoomfy, smooth))!=NULL) {
				switch (position) {
					case POSITION_CENTER:
						dest.x = (screen->w - rotozoom_picture->w)/2;
						dest.y = (screen->h - rotozoom_picture->h)/2;
						break;
					case POSITION_BOTTOMRIGHT:
						dest.x = (screen->w/2) - rotozoom_picture->w;
						dest.y = (screen->h/2) - rotozoom_picture->h;
						break;
				}
				dest.w = rotozoom_picture->w;
				dest.h = rotozoom_picture->h;
				if ( SDL_BlitSurface(rotozoom_picture, NULL, screen, &dest) < 0 ) {
					fprintf(stderr, "Blit failed: %s\n", SDL_GetError());
					break;
				}
				SDL_FreeSurface(rotozoom_picture);
			}
		}
		else {
			angle=framecount*rotate;
			if ((framecount % 120)==0) printf ("  Frame: %i   Rotate: angle=%.2f  Zoom: f=%.2f \n",framecount,angle,zoomf);
			if ((rotozoom_picture=rotozoomSurface (picture, angle, zoomf, smooth))!=NULL) {
				switch (position) {
					case POSITION_CENTER:
						dest.x = (screen->w - rotozoom_picture->w)/2;
						//dest.y = (screen->h - rotozoom_picture->h)/4;
						dest.y = 50;
						break;
					case POSITION_BOTTOMRIGHT:
						dest.x = (screen->w/2) - rotozoom_picture->w;
						dest.y = (screen->h/2) - rotozoom_picture->h;
						break;
				}
				dest.w = rotozoom_picture->w;
				dest.h = rotozoom_picture->h;
				if ( SDL_BlitSurface(rotozoom_picture, NULL, screen, &dest) < 0 ) {
					fprintf(stderr, "Blit failed: %s\n", SDL_GetError());
					break;
				}
				SDL_FreeSurface(rotozoom_picture);
			}
		}

		stringRGBA(screen, 8, 8, messageText, 255, 255, 255, 255);

		/* Display by flipping screens */
		SDL_Flip(screen);

		/* Maybe delay */
		if (delay>0) SDL_Delay(delay);
	}

	/* Pause for a sec */
	SDL_Delay(3000);
}




#define ROTATE_OFF	0
#define ROTATE_ON	1

#define FLIP_OFF	0
#define FLIP_X		1
#define FLIP_Y		2
#define FLIP_XY		3





void TestRotozoomSTurri::Draw(SDL_Surface *screen, int start, int end)
{
	SDL_Surface *picture, *picture_again;
	char *bmpfile;
	char *pngfile;	

	/* Define masking bytes */
#if SDL_BYTEORDER == SDL_BIG_ENDIAN
	Uint32 rmask = 0xff000000; 
	Uint32 gmask = 0x00ff0000;
	Uint32 bmask = 0x0000ff00; 
	Uint32 amask = 0x000000ff;
#else
	Uint32 amask = 0xff000000; 
	Uint32 bmask = 0x00ff0000;
	Uint32 gmask = 0x0000ff00; 
	Uint32 rmask = 0x000000ff;
#endif

	/* Load the image into a surface */
	SDL_Surface *image;
	SDL_RWops *rwop;
	pngfile = "title-32.png";
	rwop=SDL_RWFromFile(pngfile, "rb");
	printf("Loading picture: %s\n", pngfile);
	picture=IMG_LoadPNG_RW(rwop);

	if ( picture == NULL ) {
		fprintf(stderr, "Couldn't load %s: %s\n", pngfile, SDL_GetError());
		return;
	}
	sprintf(messageText, "8a.  rotozoom: Just zooming (angle=0), no interpolation, centered");
	RotatePicture(screen,picture,ROTATE_OFF,FLIP_OFF,SMOOTHING_OFF,POSITION_CENTER);

	/* Free the picture */
	SDL_FreeSurface(picture);

	return;
}

/*!
 \brief SDL_rotozoom test
*/
int TestRotozoomSTurri::maint( int argc, char *argv[] )
{
	SDL_Surface *screen;
	int w, h;
	int desired_bpp;
	Uint32 video_flags;
	int start, end;

	/* Title */
	fprintf(stderr,"SDL_rotozoom test\n");
	messageText = (char *)malloc(128);

	/* Set default options and check command-line */
	w = 640;
	h = 480;
	desired_bpp = 0;
	video_flags = 0;
	start = 1;
	end = 9999;
	delay = 1;
	while ( argc > 1 ) {
		if ( strcmp(argv[1], "-width") == 0 ) {
			if ( argv[2] && ((w = atoi(argv[2])) > 0) ) {
				argv += 2;
				argc -= 2;
			}
			else {
				fprintf(stderr, "The -width option requires an argument\n");
				exit(1);
			}
		} 
		else if ( strcmp(argv[1], "-height") == 0 ) {
			if ( argv[2] && ((h = atoi(argv[2])) > 0) ) {
				argv += 2;
				argc -= 2;
			} 
			else {
				fprintf(stderr, "The -height option requires an argument\n");
				exit(1);
			}
		}
		else if ( strcmp(argv[1], "-bpp") == 0 ) {
			if ( argv[2] ) {
				desired_bpp = atoi(argv[2]);
				argv += 2;
				argc -= 2;
			}
			else {
				fprintf(stderr, "The -bpp option requires an argument\n");
				exit(1);
			}
		}
		else if ( strcmp(argv[1], "-warp") == 0 ) {
			video_flags |= SDL_HWPALETTE;
			argv += 1;
			argc -= 1;
		}
		else if ( strcmp(argv[1], "-hw") == 0 ) {
			video_flags |= SDL_HWSURFACE;
			argv += 1;
			argc -= 1;
		}
		else if ( strcmp(argv[1], "-fullscreen") == 0 ) {
			video_flags |= SDL_FULLSCREEN;
			argv += 1;
			argc -= 1;
		}
		else if ( strcmp(argv[1], "-custom") == 0 ) {
			if (( argv[2] ) && ( argv[3] ) && ( argv[4] ) && (argv[5] )) {
				custom_angle = atof(argv[2]);
				custom_fx = atof(argv[3]);
				custom_fy = atof(argv[4]);
				custom_smooth = atoi(argv[5]);
				argv += 5;
				argc -= 5;
			}
			else {
				fprintf(stderr, "The -custom option requires 4 arguments\n");
				exit(1);
			}
		}
		else if (( strcmp(argv[1], "-help") == 0 ) || (strcmp(argv[1], "--help") == 0)) {
			printf ("Usage:\n");
			printf (" -start #	  Set starting test number\n");
			printf ("             1=8bit, 7=24bit, 13=32bit, 19=32bit flip, 23=custom, 25=rotate90\n");
			printf ("             26=zoom accuracy\n");
			printf (" -delay #        Set delay between frames in ms (default: 0=off)\n");
			printf ("                 (if >0, enables verbose frame logging\n");
			printf (" -width #	  Screen width (Default: %i)\n",w);
			printf (" -height #	  Screen height (Default: %i)\n",h);
			printf (" -bpp #	  Screen bpp\n");
			printf (" -warp		  Enable hardware palette\n");
			printf (" -hw		  Enable hardware surface\n");
			printf (" -fullscreen	  Enable fullscreen mode\n");
			printf (" -custom # # #	# Custom: angle scalex scaley smooth\n");
			printf ("                  scalex/scaley<0, enables flip on axis\n");
			printf ("                  smooth=0/1\n");
			exit(0);
		}
		else break;
	}

	/* Force double buffering */
	video_flags |= SDL_DOUBLEBUF;

	/* Initialize SDL */
	if ( SDL_Init(SDL_INIT_VIDEO) < 0 ) {
		fprintf(stderr,
			"Couldn't initialize SDL: %s\n", SDL_GetError());
		exit(1);
	}
	atexit(SDL_Quit);			/* Clean up on exit */

	/* Initialize the display */
	screen = SDL_SetVideoMode(w, h, desired_bpp, video_flags);
	if ( screen == NULL ) {
		fprintf(stderr, "Couldn't set %dx%dx%d video mode: %s\n",
			w, h, desired_bpp, SDL_GetError());
		exit(1);
	}

	/* Show some info */
	printf("Set %dx%dx%d mode\n",
		screen->w, screen->h, screen->format->BitsPerPixel);
	printf("Video surface located in %s memory.\n",
		(screen->flags&SDL_HWSURFACE) ? "video" : "system");

	/* Check for double buffering */
	if ( screen->flags & SDL_DOUBLEBUF ) {
		printf("Double-buffering enabled - good!\n");
	}

	/* Set the window manager title bar */
	SDL_WM_SetCaption("SDL_rotozoom test", "rotozoom");

	/* Do all the drawing work */
	Draw(screen, start, end);	
	free(messageText);

	return(0);
}


TestRotozoomSTurri::TestRotozoomSTurri() {
	maint();
}
~TestRotozoomSTurri::TestRotozoomSTurri() {
}