#ifndef SUPERTURR_TESTROTOZOOMSTURRI_H
#define SUPERTURR_TESTROTOZOOMSTURRI_H

// #include <vector>
// #include <string>

class TestRotozoomSTurri;

class TestRotozoomSTurri
{
private:
//  bool quit;

/*  Surface* level_sprite;
  Surface* leveldot_green;
  Surface* leveldot_red;
  Surface* leveldot_teleporter;

  std::string name;
  std::string music;

  std::vector<int> tilemap;
  int width;
  int height;
  
  int start_x;
  int start_y;

  TileManager* tile_manager;*/

private:
/*  typedef std::vector<Level> Levels;
  Levels levels;

  MusicRef song;

  Direction input_direction;
  bool enter_level;

  Point offset;
  std::string savegame_file;
  std::string map_file;

  void get_level_title(Levels::pointer level);

  void draw_status();*/
public:
  TestRotozoomSTurri();
  ~TestRotozoomSTurri();

	void HandleEvent();
	void ClearScreen(SDL_Surface *screen);
	void RotatePicture (SDL_Surface *screen, SDL_Surface *picture, int rotate, int flip, int smooth, int position, SDL_Surface *background);
	void Draw (SDL_Surface *screen, int start, int end);
	int maint();
	
	
//  void set_map_file(std::string mapfile);
  

  /** Busy loop */
//  void display();

//  void load_map();
  
//  void get_input();

  /** Update Turri position */
//  void update(float delta);

  /** Draw one frame */
//  void draw(const Point& offset);

//  Point get_next_tile(Point pos, Direction direction);
//  Tile* at(Point pos);
//  WorldMap::Level* at_level();

  /** Check if it is possible to walk from \a pos into \a direction,
      if possible, write the new position to \a new_pos */
//  bool path_ok(Direction direction, Point pos, Point* new_pos);

//  void savegame(const std::string& filename);
//  void loadgame(const std::string& filename);
//  void loadmap(const std::string& filename);

//  const std::string& get_world_title() const
//    { return name; }
  
//  const int& get_start_x() const
//    { return start_x; }
  
//  const int& get_start_y() const
//    { return start_y; }

  /** This functions should be call by contrib menu to set
     all levels as played, since their state is not saved. */
//  void set_levels_as_solved()
//    { for(Levels::iterator i = levels.begin(); i != levels.end(); ++i)
//        i->solved = true;  }

private:
//  void on_escape_press();
};

// namespace WorldMapNS

#endif

/* Local Variables: */
/* mode:c++ */
/* End: */
